<?php
include "koneksi.php";
session_start();

if(empty($_SESSION['nik']))
{
  echo "<script> alert('Anda belum Loginl'); window.location.href='login.php'; </script>";
}

$tar = mysqli_num_rows(mysqli_query($con,"SELECT * FROM input_target"));
$out = mysqli_num_rows(mysqli_query($con,"SELECT * FROM input_produksi"));
$ce1 = mysqli_num_rows(mysqli_query($con,"SELECT * FROM cek_quality WHERE reason = 'OK'"));
$ce2 = mysqli_num_rows(mysqli_query($con,"SELECT * FROM cek_quality WHERE reason != 'OK'"));

      $sql2 = mysqli_query($con,"SELECT a.block, a.qty as qty1, b.qty as qty2 FROM input_produksi a LEFT JOIN input_target b ON b.block = a.block  GROUP BY block");
      $arrayFramework = array();
      $arrayNilai = array();
      $arrayNilai2 = array();
        if ($sql2->num_rows > 0) {
          while($row = $sql2->fetch_assoc()) {
            $arrayFramework[] = '"'.$row['block'].'"';
            $arrayNilai[] = $row['qty1'];
            $arrayNilai2[] = $row['qty2'];
          }
    }

?>

<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>MES - Production Ouput</title>

  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">

  <link rel="stylesheet" href="vendor/datatables/dataTables.bootstrap4.min.css" />
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.6/css/buttons.dataTables.min.css" />
  <script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
  <script src="https://code.highcharts.com/highcharts.js"></script>
  <script src="https://code.highcharts.com/modules/exporting.js"></script>
  <script src="https://code.highcharts.com/modules/export-data.js"></script>

</head>

<body id="page-top">

  <!-- Page Wrapper -->
  <div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

      <!-- Sidebar - Brand -->
      <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
        <div class="sidebar-brand-icon rotate-n-15">
          <i class="fas fa-fw fa-chart-area"></i>
        </div>
        <div class="sidebar-brand-text mx-3">MES <sup>Output Production</sup></div>
      </a>

      <!-- Divider -->
      <hr class="sidebar-divider my-0">

      <!-- Nav Item - Dashboard -->
      <li class="nav-item active">
        <a class="nav-link" href="?page=dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Report
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="true" aria-controls="collapseTwo">
          <i class="fas fa-fw fa-table"></i>
          <span>Report By Target</span>
        </a>
        <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Schedule Report</h6>
            <a class="collapse-item" href="?page=report">Table Report</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider">

      <!-- Heading -->
      <div class="sidebar-heading">
        Utilities
      </div>

      <!-- Nav Item - Pages Collapse Menu -->
      <li class="nav-item">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapsePages" aria-expanded="true" aria-controls="collapsePages">
           <i class="fas fa-fw fa-wrench"></i>
          <span>Manage User</span>
        </a>
        <div id="collapsePages" class="collapse" aria-labelledby="headingPages" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Planning</h6>
            <a class="collapse-item" href="?page=planning">Planning User</a>
            <div class="collapse-divider"></div>
            <h6 class="collapse-header">Operator</h6>
            <a class="collapse-item" href="?page=operator">Operator User</a>
          </div>
        </div>
      </li>

      <!-- Divider -->
      <hr class="sidebar-divider d-none d-md-block">

      <!-- Sidebar Toggler (Sidebar) -->
      <div class="text-center d-none d-md-inline">
        <button class="rounded-circle border-0" id="sidebarToggle"></button>
      </div>

    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

<?php
  if (@$_GET['page'] == '' or @$_GET['page'] == 'dashboard') {include "pages/dashboard/dashboard.php"; }
  elseif (@$_GET['page'] == 'report' and @$_GET['aksi'] == ''){include "pages/report/report.php"; }
  elseif (@$_GET['page'] == 'target' and @$_GET['aksi'] == ''){include "pages/target/target.php"; }
  elseif (@$_GET['page'] == 'target' and @$_GET['aksi'] == 'edit_target'){include "pages/target/edit_target.php"; }
  elseif (@$_GET['page'] == 'target' and @$_GET['aksi'] == 'hapus_target'){include "pages/target/hapus_target.php"; }
  elseif (@$_GET['page'] == 'target' and @$_GET['aksi'] == 'tambah_target'){include "pages/target/tambah_target.php"; }
  elseif (@$_GET['page'] == 'planning' and @$_GET['aksi'] == ''){include "pages/planning/planning.php"; }
  elseif (@$_GET['page'] == 'planning' and @$_GET['aksi'] == 'edit_planning'){include "pages/planning/edit_planning.php"; }
  elseif (@$_GET['page'] == 'planning' and @$_GET['aksi'] == 'hapus_planning'){include "pages/planning/hapus_plannig.php"; }
  elseif (@$_GET['page'] == 'planning' and @$_GET['aksi'] == 'tambah_planning'){include "pages/planning/tambah_planning.php"; }
  elseif (@$_GET['page'] == 'output' and @$_GET['aksi'] == ''){include "pages/output/output.php"; }
  elseif (@$_GET['page'] == 'output' and @$_GET['aksi'] == 'edit_output'){include "pages/output/edit_output.php"; }
  elseif (@$_GET['page'] == 'output' and @$_GET['aksi'] == 'hapus_output'){include "pages/output/hapusoutputt.php"; }
  elseif (@$_GET['page'] == 'output' and @$_GET['aksi'] == 'tambah_output'){include "pages/output/tambah_output.php"; }
  elseif (@$_GET['page'] == 'operator' and @$_GET['aksi'] == ''){include "pages/operator/operator.php"; }
  elseif (@$_GET['page'] == 'operator' and @$_GET['aksi'] == 'edit_operator'){include "pages/operator/edit_operator.php"; }
  elseif (@$_GET['page'] == 'operator' and @$_GET['aksi'] == 'hapus_operator'){include "pages/operator/hapus_operator.php"; }
  elseif (@$_GET['page'] == 'operator' and @$_GET['aksi'] == 'tambah_operator'){include "pages/operator/tambah_operator.php"; }
  elseif (@$_GET['page'] == 'check' and @$_GET['aksi'] == ''){include "pages/check/check.php"; }
  elseif (@$_GET['page'] == 'check' and @$_GET['aksi'] == 'edit_check'){include "pages/check/edit_check.php"; }
  elseif (@$_GET['page'] == 'check' and @$_GET['aksi'] == 'hapus_check'){include "pages/check/hapus_check.php"; }
  elseif (@$_GET['page'] == 'check' and @$_GET['aksi'] == 'tambah_check'){include "pages/check/tambah_check.php"; } 
  elseif (@$_GET['page'] == 'report' and @$_GET['aksi'] == ''){include "pages/report/report.php"; }
?>
      <!-- Footer -->
      <footer class="sticky-footer bg-white">
        <div class="container my-auto">
          <div class="copyright text-center my-auto">
            <span>Copyright &copy; Your Website 2019</span>
          </div>
        </div>
      </footer>
      <!-- End of Footer -->

    </div>
    <!-- End of Content Wrapper -->

  </div>
  <!-- End of Page Wrapper -->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>


  <!-- Bootstrap core JavaScript-->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Page level plugins -->
  <script src="vendor/chart.js/Chart.min.js"></script>

  <!-- Page level custom scripts -->
  <script src="js/demo/chart-area-demo.js"></script>
  <script src="js/demo/chart-pie-demo.js"></script>
   <script src="vendor/datatables/jquery.dataTables.min.js"></script>
   <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.6/js/dataTables.buttons.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.flash.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.html5.min.js"></script>
   <script src="https://cdn.datatables.net/buttons/1.5.6/js/buttons.print.min.js"></script>
  <script type="text/javascript">
    $(document).ready(function(){
      $('#dataTable').DataTable();
      $('#dataTable2').DataTable({
        dom: 'Bfrtip',
        buttons: [
             'excel', 'pdf', 'print'
        ]
    });
    });
  </script>
<script type="text/javascript">
                        $(function(){
  var chart = new Highcharts.Chart({
      chart: {
          renderTo: 'container',
          type: 'bar',
      },
      title: {
          text: 'Production Output by Target Daily'
      },
      xAxis: {
          categories: [<?= join($arrayFramework, ',') ?>],
          title: {
              text: null
          }
      },
      yAxis: {
          min: 0,
          title: {
              text: 'request / sec',
              align: 'high'
          },
          labels: {
              overflow: 'justify'
          }
      },
      tooltip: {
          valueSuffix: ' req / sec'
      },
      plotOptions: {
          bar: {
              dataLabels: {
                  enabled: true
              }
          }
      },
      legend: {
          layout: 'vertical',
          align: 'right',
          verticalAlign: 'top',
          x: -40,
          y: 80,
          floating: true,
          borderWidth: 1,
          backgroundColor: ((Highcharts.theme && Highcharts.theme.legendBackgroundColor) || '#FFFFFF'),
          shadow: true
      },
      credits: {
          enabled: false
      },
      series: [{
          name: 'Output',
          data: [<?= join($arrayNilai, ',') ?>],
          color: 'blue',
      },{
          name: 'Target',
          data: [<?= join($arrayNilai2, ',') ?>],
          color: '#FFB41A',
      }
      ]
  });
});
          </script>

</body>

</html>

