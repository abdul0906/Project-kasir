<?php 
include "koneksi.php";
$id = $_GET['id'];
          $edit= mysqli_query($con,"DELETE FROM tbl_admin WHERE id='$id'");
          
          if($edit) {
            echo '<script>
              alert("Data berhasil dihapus!");
              window.location.href="index.php?page=operator";
            </script>';
          }         


      ?>