-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 25, 2019 at 01:42 PM
-- Server version: 10.1.39-MariaDB
-- PHP Version: 7.3.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mes`
--

-- --------------------------------------------------------

--
-- Table structure for table `cek_quality`
--

CREATE TABLE `cek_quality` (
  `id` int(9) NOT NULL,
  `date` date NOT NULL,
  `code` varchar(8) NOT NULL,
  `qty` int(3) NOT NULL,
  `reason` varchar(11) NOT NULL,
  `block` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cek_quality`
--

INSERT INTO `cek_quality` (`id`, `date`, `code`, `qty`, `reason`, `block`) VALUES
(1, '2019-08-25', 'FAQ30', 10, 'OK', 'B11'),
(2, '2019-08-25', 'FAQ30', 10, 'REJECT', 'B11');

-- --------------------------------------------------------

--
-- Table structure for table `input_produksi`
--

CREATE TABLE `input_produksi` (
  `id` int(9) NOT NULL,
  `date` date NOT NULL,
  `user` varchar(5) NOT NULL,
  `code` varchar(8) NOT NULL,
  `block` varchar(4) NOT NULL,
  `qty` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `input_produksi`
--

INSERT INTO `input_produksi` (`id`, `date`, `user`, `code`, `block`, `qty`) VALUES
(4, '2019-08-25', '08629', 'FAQ30', 'B11', 20),
(5, '2019-08-25', '08629', 'FAQ31', 'A12', 10);

-- --------------------------------------------------------

--
-- Table structure for table `input_target`
--

CREATE TABLE `input_target` (
  `id` int(9) NOT NULL,
  `date` date NOT NULL,
  `block` varchar(4) NOT NULL,
  `code` varchar(8) NOT NULL,
  `name` varchar(11) NOT NULL,
  `qty` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `input_target`
--

INSERT INTO `input_target` (`id`, `date`, `block`, `code`, `name`, `qty`) VALUES
(1, '2019-08-25', 'B11', 'FAQ30', 'SEAT 37', 100),
(2, '2019-08-25', 'A12', 'FAQ31', 'REG 27', 87);

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(3) NOT NULL,
  `code` varchar(8) NOT NULL,
  `name` varchar(11) NOT NULL,
  `detail` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item`
--

INSERT INTO `item` (`id`, `code`, `name`, `detail`) VALUES
(1, 'F4356', 'SWEAT J60', 'CUTTON\r\nSHORT'),
(2, 'F4377', 'SWEAT 7YT', 'LONG\r\nDRESS'),
(3, 'F4351', 'REG 67', 'SHORT\r\nPANTS');

-- --------------------------------------------------------

--
-- Table structure for table `report`
--

CREATE TABLE `report` (
  `id` int(9) NOT NULL,
  `date` date NOT NULL,
  `target_qty` int(3) NOT NULL,
  `imp_qty` int(3) NOT NULL,
  `user` varchar(5) NOT NULL,
  `code` varchar(8) NOT NULL,
  `block` varchar(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `id` int(3) NOT NULL,
  `nik` varchar(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `pass` varchar(10) NOT NULL,
  `level` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`id`, `nik`, `name`, `pass`, `level`) VALUES
(1, '08629', 'Abdullah', '123456', 'A'),
(2, '00751', 'Rusli A', '123321', 'B');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(4) NOT NULL,
  `nik` varchar(6) NOT NULL,
  `name` varchar(30) NOT NULL,
  `block` varchar(4) NOT NULL,
  `level` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `nik`, `name`, `block`, `level`) VALUES
(3, '11111', 'Yusron', 'A11', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cek_quality`
--
ALTER TABLE `cek_quality`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `input_produksi`
--
ALTER TABLE `input_produksi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `input_target`
--
ALTER TABLE `input_target`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `report`
--
ALTER TABLE `report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cek_quality`
--
ALTER TABLE `cek_quality`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `input_produksi`
--
ALTER TABLE `input_produksi`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `input_target`
--
ALTER TABLE `input_target`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `report`
--
ALTER TABLE `report`
  MODIFY `id` int(9) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_admin`
--
ALTER TABLE `tbl_admin`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
