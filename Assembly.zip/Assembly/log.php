<?php
  include "koneksi.php";

  $nik = $_POST['nik'];
  $pass = $_POST['pass'];

  $sql = mysqli_query($con,"SELECT * FROM tbl_admin WHERE nik='$nik' AND pass='$pass'");
  $cek = mysqli_num_rows($sql);
  $view = mysqli_fetch_array($sql);

  if($cek == 1) {
  session_start();
	  $_SESSION['nik'] = $view['nik'];
	  $_SESSION['name'] = $view['name'];
		echo "<script> window.location.href='index.php'; </script>";
	}

	else {
echo "<script> alert('Login Gagal'); window.location.href='login.php'; </script>";
	}	

  ?>